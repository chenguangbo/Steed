package com.trs.测试;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.trs.utils.Loader;
import java.net.URL;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

@SuppressWarnings("all")
public class Test2 {

	public static void main(String[] args) {
		try {
			URL url = Loader.getResource("z.properties");
			File file = new File(url.getFile());
			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new FileReader(file));
			} catch (FileNotFoundException e) {
				System.out.println("读取配置文件失败");
			}
			reader.readLine();// 舍弃第一行注释
			String idMap = null;
			
			while (reader.readLine() != null) {

				if (idMap.indexOf("/") > 0) {
					idMap = idMap.substring(0, idMap.indexOf("/"));
				}
			}
				Document doc3 = Jsoup.connect("https://zhidao.baidu.com/question/571169183.html").post();
				Elements select = doc3.select("a");
				for (Element element : select) {
					String attr2 = element.attr("href");
					if(!attr2.contains("http")){
						String baseUri = doc3.baseUri();
						int lastIndexOf = baseUri.lastIndexOf("/");
						String substring = baseUri.substring(0, lastIndexOf);
						System.out.println("拼接数据："+substring+attr2);
					}else{
						
					System.out.println("attr2:" + attr2);
					}
				}

				Document html = Jsoup.connect("https://zhidao.baidu.com/question/571169183.html").get();
			//	System.err.println(html);
				Elements select2 = html.select("a");
				
				for (Element element : select2) {
					System.err.println(element);;
				}
				
			//	[a-zA-z]+://[^\s]*
				
				String e = "[a-zA-z]+://[^\\s]*";
				
				
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
