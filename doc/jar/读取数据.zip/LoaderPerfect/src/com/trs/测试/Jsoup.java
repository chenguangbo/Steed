package com.trs.测试;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.jsoup.helper.Validate;
import com.trs.domain.Parameters;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;

public class Jsoup {

	public static void main(String[] args) throws Exception {
		
		CloseableHttpClient httpclient = HttpClients.createDefault(); // 创建httpclient实例
        HttpGet httpget = new HttpGet("http://www.pep.com.cn/dzyx1/cpzx_195429/?xdtype=300&xktype=440"); // 创建httpget实例
         
        CloseableHttpResponse response = httpclient.execute(httpget); // 执行get请求
        HttpEntity entity=response.getEntity(); // 获取返回实体
        String content=EntityUtils.toString(entity, "utf-8");
        response.close(); // 关闭流和释放系统资源
        System.out.println(content);
      //  Validate.isTrue(true, content);
        
	}
	
	
	public static void send() throws Exception{
		//创建可关闭的的httpclient对象
		CloseableHttpClient httpCli = HttpClients.createDefault();
		//创建Get方式请求对象
		HttpGet get = new HttpGet("http://www.pep.com.cn/dzyx1/cpzx_195429/");
		//参数集合
		List<Parameters> list = new ArrayList<Parameters>();
		list.add(new Parameters("xdtype","300"));
		list.add(new Parameters("xktype","440"));
		
		List<NameValuePair> list2 = new ArrayList<NameValuePair>();
		list2.add(new BasicNameValuePair("xdtype","300"));
		list2.add(new BasicNameValuePair("xktype","440"));
		
		HttpMethod httpMethod = new GetMethod("http://java.sun.com");  
	    httpMethod.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset="
                        + "UTF-8");
	   // httpCli.
	    //client.executeMethod(httpMethod);  
		//HttpContext request;
		//httpCli.execute("http://www.pep.com.cn/dzyx1/cpzx_195429/", request);
	//	new UrlEncodedFormEntity((List<? extends NameValuePair>) list);
		
	}
	
	
}
