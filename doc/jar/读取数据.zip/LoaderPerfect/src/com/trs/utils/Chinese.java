package com.trs.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Chinese {

	public static void main(String[] args) {
    	String str = "123abc��dfc";
                      //ͷ��β
    	String reg = "[\u4e00-\u9fa5]+";
    	//���һ��ƥ����
    	Pattern compile = Pattern.compile(reg);
    	Pattern pat = Pattern.compile(reg);  
    	Matcher mat=pat.matcher(str); 

    	String repickStr = mat.replaceAll("");

    	System.out.println("ȥ���ĺ�:"+repickStr);
	}

}
